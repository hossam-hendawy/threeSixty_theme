Please visit our website if you are interested in translating our plugin, see the links below.

Our translations are now managed at our GlotPress install: https://support.themecatcher.net/glotpress/projects

Translating guide (if not using GlotPress): https://support.themecatcher.net/quform-wordpress-v2/guides/advanced/translating-the-plugin

If you've made an improvement to an existing translation, please consider sending both the .mo and .po files to info@themecatcher.net, so we can include your improvements in the next version of the plugin.

Warning: If you change a translation file included with the plugin it will be overwritten when the plugin is upgraded.
